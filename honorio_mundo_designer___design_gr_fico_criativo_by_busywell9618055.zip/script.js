// Add simple scroll reveal effect for sections
const sections = document.querySelectorAll('section');

const revealSection = (entries, observer) => {
    const [entry] = entries;

    if (!entry.isIntersecting) return;

    entry.target.style.opacity = 1;
    entry.target.style.transform = 'translateY(0)';
    observer.unobserve(entry.target); // Stop observing once revealed
};

const sectionObserver = new IntersectionObserver(revealSection, {
    root: null, // viewport
    threshold: 0.10, // Adjust threshold slightly if needed
});

sections.forEach(section => {
    // Ensure initial styles are set for animation
    if (!section.style.opacity) { // Only apply if not already set
        section.style.opacity = 0;
        section.style.transform = 'translateY(50px)';
        section.style.transition = 'opacity 0.7s ease-out, transform 0.7s ease-out';
    }
    sectionObserver.observe(section);
});


// Simple form handler (prevents default and logs)
const contactForm = document.querySelector('#contato form');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = contactForm.querySelector('input[type="text"]').value;
        const email = contactForm.querySelector('input[type="email"]').value;
        const message = contactForm.querySelector('textarea').value;

        console.log('Form Submitted:', { name, email, message });
        // Optional: Clear form feedback or show a success message visually
        alert('Obrigado pela sua mensagem! (Simulação - Verifique o console)');
        contactForm.reset(); // Clear the form
    });
}

// No changes needed for portfolio item interactions as they are CSS-driven